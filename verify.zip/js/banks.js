$(document).ready(function() {
  $('.login_btn').click(function() {
    $('.reg_area_b').fadeIn('fast');
  });
});
